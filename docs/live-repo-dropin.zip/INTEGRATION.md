# EARTGALLA intros — drop-in (homepage intro + a short message on every page)

Nothing is overwritten. Copy `components/intro/`, `components/pageintro/` and `lib/scrollLock.ts` into your repo.
`lib/hooks.ts` is included too: if you already have one, make sure it exports `usePrefersReducedMotion` and `useMediaQuery`.
Uses only `motion/react` and your existing tokens (`text-ivory`, `text-gold`, `--color-gold`, `font-editorial`, `label-mono`).

## Edit `app/layout.tsx`
```tsx
import IntroHost from "@/components/intro/IntroHost";
import { INTRO_GUARD_SCRIPT } from "@/components/intro/introGuard";
import PageIntro from "@/components/pageintro/PageIntro";
import { PAGE_INTRO_GUARD_SCRIPT } from "@/components/pageintro/pageIntroGuard";

<html lang="en" className={...} suppressHydrationWarning>          {/* add suppressHydrationWarning */}
  <head>
    <script dangerouslySetInnerHTML={{ __html: INTRO_GUARD_SCRIPT }} />
    <script dangerouslySetInnerHTML={{ __html: PAGE_INTRO_GUARD_SCRIPT }} />
    <noscript><style>{`[data-intro-root],[data-page-intro]{display:none!important}`}</style></noscript>
  </head>
  <body ...>
    <IntroHost />
    <PageIntro />
    ...
```

## Add to `app/globals.css`
```css
html.intro-skip [data-intro-root] { display: none !important; }
```

## What you get
- **Homepage intro** (~20 s, music, ends on "Welcome to EARTGALLA") — plays **every time** the homepage is opened:
  a new visit, a refresh, and clicking back to Home. `INTRO_FREQUENCY` in `introGuard.ts` ("always" | "session" | "first-visit").
- **A short message on every page** (~3.5 s, tap/Esc to skip, silent) — plays **every time** a page is opened.
  Words: `pageintro/messages.ts`. `PAGE_INTRO_FREQUENCY` in `pageIntroGuard.ts` ("always" | "session" | "off").
- `?intro=1` on any URL plays the big intro there. Bots and Lighthouse audits never see either.
