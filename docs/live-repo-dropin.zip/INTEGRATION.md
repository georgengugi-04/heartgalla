# EARTGALLA intros — drop-in (homepage intro + a short message on every page)

Nothing is overwritten. Copy `components/intro/`, `components/pageintro/` and `lib/scrollLock.ts` into your repo.
`lib/hooks.ts` is included too: if you already have one, just make sure it exports `usePrefersReducedMotion` and `useMediaQuery`.
Uses only `motion/react` and your existing tokens (`text-ivory`, `text-gold`, `--color-gold`, `font-editorial`, `label-mono`).

## Edit `app/layout.tsx`
```tsx
import IntroSplash from "@/components/intro/IntroSplash";
import { INTRO_GUARD_SCRIPT } from "@/components/intro/introGuard";
import PageIntro from "@/components/pageintro/PageIntro";
import { PAGE_INTRO_GUARD_SCRIPT } from "@/components/pageintro/pageIntroGuard";

<html lang="en" className={...} suppressHydrationWarning>          {/* add suppressHydrationWarning */}
  <head>
    <script dangerouslySetInnerHTML={{ __html: INTRO_GUARD_SCRIPT }} />
    <script dangerouslySetInnerHTML={{ __html: PAGE_INTRO_GUARD_SCRIPT }} />
    <noscript><style>{`[data-intro-root],[data-page-intro]{display:none!important}`}</style></noscript>
  </head>
  <body ...>
    <IntroSplash />
    <PageIntro />
    ...
```

## Add to `app/globals.css`
```css
html.intro-skip [data-intro-root] { display: none !important; }
```

## What you get
- **Homepage intro** (~20 s, with music, ends on "Welcome to EARTGALLA"). Frequency: `INTRO_FREQUENCY` in `introGuard.ts`.
- **A short message on every page** (~3.5 s, tap/Esc to skip, silent). Words: `pageintro/messages.ts`. Frequency: `PAGE_INTRO_FREQUENCY` in `pageIntroGuard.ts`.
- `?intro=1` on any URL replays the big intro. Bots, Lighthouse and returning visits never see a flash of either.
